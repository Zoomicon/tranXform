﻿'Filename: XmlLoggingResolver
'Author: George Birbilis (http://zoomicon.com)
'Version: 20140926

Imports System.Xml

Public Class XmlLoggingResolver
  Inherits XmlUrlResolver

  Public Overrides Function GetEntity(absoluteUri As Uri, role As String, ofObjectToReturn As Type) As Object
    If (absoluteUri = Nothing) Then Throw New ArgumentNullException("absoluteUri")

    Debug.Print(absoluteUri)

    MyBase.GetEntity(absoluteUri, role, ofObjectToReturn)
  End Function

End Class
