﻿//Filename: XmlLoggingResolver
//Author: George Birbilis (http://zoomicon.com)
//Version: 20140926

public class XmlLoggingResolver : XmlUrlResolver
{

  public override object GetEntity(Uri absoluteUri, string role, Type ofObjectToReturn)
  {
    if (absoluteUri == null)
      throw new ArgumentNullException("absoluteUri");



    base.GetEntity(absoluteUri, role, ofObjectToReturn);
  }

}