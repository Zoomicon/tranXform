C2PasFilter - a simple C to Pascal source reformatter
(C) George Birbilis <birbilis@kagi.com> - Agrinio Club

mainly for use with the QuickTime headers

e.g. copy 

int x;
float y;

to the upper text area, press the "var" button and you get

x:int;
y:float;

at the bottom text area