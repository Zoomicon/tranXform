﻿Public Class XmlDumpingResolver

End Class
